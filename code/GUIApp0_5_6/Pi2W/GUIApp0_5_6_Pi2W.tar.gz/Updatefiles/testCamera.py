import sys
import time
import signal
from picamera2 import MappedArray, Picamera2, Preview
from libcamera import Transform, controls

captured_QR = False

def alarm_handler(signum, frame):
	picam2.stop()
	sys.exit("No QR-code found")
	
def read_QR(request):	
	with MappedArray(request, "main") as m:
		for b in QRcodes:
			picam2.stop()
			captured_QR = True

signal.signal(signal.SIGALRM, alarm_handler)
signal.alarm(30)

picam2 = Picamera2()
picam2.start_preview(Preview.QTGL, x=640, y=420, width=640, height=480, transform=Transform(hflip=True, vflip=False))

QRcodes = []
picam2.post_callback = read_QR

picam2.start()

try:
	picam2.set_controls({"AfMode": controls.AfModeEnum.Continuous})
except:
	print("No autofocus")

time.sleep(0.1)

while not captured_QR:
	rgb = picam2.capture_array("main")
	time.sleep(0.001)
