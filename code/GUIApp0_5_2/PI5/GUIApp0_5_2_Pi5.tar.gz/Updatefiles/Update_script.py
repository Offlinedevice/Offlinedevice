#!/usr/bin/env python3
#
#  Update script for GUIApp.py v0.5.2 for Rapberry Pi 5
#  
#  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, 
#  version 2 of the License.

#  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
#  See the GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

#  SPDX-License-Identifier: GPL-2.0-only
#  GUIApp.py - Offline device.
#  Copyright (c) 2024 

import tkinter
import shutil
from tkinter import messagebox

answer = messagebox.askquestion('Important!', 'Before installing version 0.5.2, for the Pi 5 you need to have full image version 0.5.2 or later installed.\n Do you have that?')

if answer == 'yes':
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/GUIApp.py', '/home/user1/GUIApp.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/take_picture.py', '/home/user1/take_picture.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/take_ID_picture.py', '/home/user1/take_ID_picture.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/scanQRforSigning.py', '/home/user1/scanQRforSigning.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/scanQRmessage.py', '/home/user1/scanQRmessage.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/testCamera.py', '/home/user1/testCamera.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/scanQRforAddress.py', '/home/user1/scanQRforAddress.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/scanQR.py', '/home/user1/scanQR.py')
	
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/btc_wallet_icon.jpg', '/home/user1/images/btc_wallet_icon.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Savings_plant.JPG', '/home/user1/images/Savings_plant.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/savings_pig.JPG', '/home/user1/images/savings_pig.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Shopping_tech.JPG', '/home/user1/images/Shopping_tech.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/lines.png', '/home/user1/images/lines.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/blue_ID.png', '/home/user1/images/blue_ID.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/red_ID.png', '/home/user1/images/red_ID.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/green_ID.png', '/home/user1/images/green_ID.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/orange_ID.png', '/home/user1/images/orange_ID.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Bank_app.JPG', '/home/user1/images/Bank_app.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Privacy_1.JPG', '/home/user1/images/Privacy_1.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Signer_1.JPG', '/home/user1/images/Signer_1.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Buddha.JPG', '/home/user1/images/Buddha.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Blackcat.JPG', '/home/user1/images/Blackcat.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Teddy_bear.jpg', '/home/user1/images/Teddy_bear.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/white.png', '/home/user1/images/white.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/barcode_GnuPG.png', '/home/user1/images/barcode_GnuPG.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Dices_gold_icon.jpg', '/home/user1/images/Dices_gold_icon.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/black.png', '/home/user1/images/black.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/off.jpg', '/home/user1/images/off.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/defaultWalletIcon.jpg', '/home/user1/images/defaultWalletIcon.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/inheritanceHelp.txt', '/home/user1/help/inheritanceHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/GnuPG_keyICON.jpg', '/home/user1/images/GnuPG_keyICON.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/ID_ICON_default.jpg', '/home/user1/Pictures/ID_ICON_default.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/gpgHelp.txt', '/home/user1/help/gpgHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/getstartedHelp.txt', '/home/user1/help/getstartedHelp.txt')

else:
	messagebox.showinfo("Information", "OK. Cancelling software update process.")
