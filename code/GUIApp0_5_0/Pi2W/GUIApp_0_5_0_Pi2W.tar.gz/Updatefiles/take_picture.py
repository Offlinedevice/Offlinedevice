from picamera2 import Picamera2, Preview
from libcamera import Transform, controls
import time

picam2 = Picamera2()
picam2.start_preview(Preview.QTGL, x=600, y=430, width=640, height=480, transform=Transform(hflip=True, vflip=True))

picam2.start()

try:
	picam2.set_controls({"AfMode": controls.AfModeEnum.Continuous})
except:
	print("No autofocus")

time.sleep(6)

picam2.capture_file("/home/user1/secure/taken_picture.jpg")
picam2.stop()
