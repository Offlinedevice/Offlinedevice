import numpy as np
from picamera2 import Picamera2, Preview
from libcamera import Transform, controls
import time

x, y, w, h = 170, 48, 300, 384
thickness = 2
color = [0, 255, 0, 255]  # Solid green

overlay = np.zeros((480, 640, 4), dtype=np.uint8)

overlay[y:y+thickness, x:x+w] = color        # Top
overlay[y+h-thickness:y+h, x:x+w] = color    # Bottom
overlay[y:y+h, x:x+thickness] = color        # Left
overlay[y:y+h, x+w-thickness:x+w] = color    # Right

picam2 = Picamera2()

config = picam2.create_still_configuration(main={"size":picam2.sensor_resolution}, lores={"size": (640, 480)}, display="lores", buffer_count=3)

picam2.configure(config)

time.sleep(1)

picam2.start_preview(Preview.QTGL, x=600, y=430, width=640, height=480, transform=Transform(hflip=True, vflip=True))

picam2.start()

o = picam2.set_overlay(overlay)

try:
	picam2.set_controls({"AfMode": controls.AfModeEnum.Continuous})
except:
	print("No autofocus")

time.sleep(6)

picam2.capture_file("/home/user1/secure/taken_ID_picture.jpg")
picam2.stop()
