#!/usr/bin/env python3
#
#  Update script for GUIApp.py v0.6.2c for Rapberry Pi Zero 2 W
#  
#  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, 
#  version 2 of the License.

#  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
#  See the GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

#  SPDX-License-Identifier: GPL-2.0-only
#  GUIApp.py - Offline device.
#  Copyright (c) 2024 

import tkinter
import shutil
from tkinter import messagebox

answer = messagebox.askquestion('Important!', 'Before installing version 0.6.2c, for the Pi Zero 2 W you need to have full image version 0.6.0 or later installed.\n Do you have that?')

if answer == 'yes':
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/GUIApp.py', '/home/user1/GUIApp.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/bankingHelp.txt', '/home/user1/help/bankingHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/boltcardHelp.txt', '/home/user1/help/boltcardHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/sigKey_shield.jpg', '/home/user1/images/sigKey_shield.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Savings.jpg', '/home/user1/images/Savings.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Shopping.jpg', '/home/user1/images/Shopping.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Bank.jpg', '/home/user1/images/Bank.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Buddha.JPG', '/home/user1/images/Buddha.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Sunsetd.jpg', '/home/user1/images/Sunsetd.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Privacy_1.JPG', '/home/user1/images/Privacy_1.JPG')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/winterbackground.jpg', '/home/user1/images/winterbackground.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/summerbackground.jpg', '/home/user1/images/summerbackground.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/winterbackgroundmid.jpg', '/home/user1/images/winterbackgroundmid.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/lightbackground.jpg', '/home/user1/images/lightbackground.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/lightbackgroundmid.jpg', '/home/user1/images/lightbackgroundmid.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/summerbackgroundmid.jpg', '/home/user1/images/summerbackgroundmid.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/Dices_gold_icon.jpg', '/home/user1/images/Dices_gold_icon.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/signingKey.jpg', '/home/user1/images/signingKey.jpg')
else:
	messagebox.showinfo("Information", "OK. Cancelling software update process.")
