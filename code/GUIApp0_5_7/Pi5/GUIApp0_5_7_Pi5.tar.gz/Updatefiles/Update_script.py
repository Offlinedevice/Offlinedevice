#!/usr/bin/env python3
#
#  Update script for GUIApp.py v0.5.7 for Rapberry Pi 5
#  
#  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, 
#  version 2 of the License.

#  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
#  See the GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

#  SPDX-License-Identifier: GPL-2.0-only
#  GUIApp.py - Offline device.
#  Copyright (c) 2024 

import tkinter
import shutil
from tkinter import messagebox

answer = messagebox.askquestion('Important!', 'Before installing version 0.5.7, for the Pi 5 you need to have full image version 0.5.6 or later installed.\n Do you have that?')

if answer == 'yes':
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/GUIApp.py', '/home/user1/GUIApp.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/critical_system_files.csv', '/home/user1/Documents/critical_system_files.csv')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/boltcardHelp.txt', '/home/user1/help/boltcardHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/securearchiveHelp.txt', '/home/user1/help/securearchiveHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/take_picture.py', '/home/user1/take_picture.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/scanQR.py', '/home/user1/scanQR.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/scanQRforAddress.py', '/home/user1/scanQRforAddress.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/scanQRforSigning.py', '/home/user1/scanQRforSigning.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/scanQRmessage.py', '/home/user1/scanQRmessage.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/take_ID_picture.py', '/home/user1/take_ID_picture.py')

else:
	messagebox.showinfo("Information", "OK. Cancelling software update process.")
