#!/usr/bin/env python3
#
#  Update script for GUIApp.py v0.3.1
#  
#  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, 
#  version 2 of the License.

#  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
#  See the GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

#  SPDX-License-Identifier: GPL-2.0-only
#  GUIApp.py - Offline device.
#  Copyright (c) 2024 

import tkinter
import shutil
from tkinter import messagebox

answer = messagebox.askquestion('Important!', 'Before update to program version 0.3.1 you have to install version 0.3.0b first.\n Have you done that?')

if answer == 'yes':
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/GUIApp.py', '/home/user1/venvpython/GUIApp.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/user_yinyang.png', '/home/user1/Pictures/user_yinyang.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/user_skull.png', '/home/user1/Pictures/user_skull.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/user_anon.png', '/home/user1/Pictures/user_anon.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/AI_woman.png', '/home/user1/Pictures/AI_woman.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/AI_boy.png', '/home/user1/Pictures/AI_boy.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/AI_man.png', '/home/user1/Pictures/AI_man.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/AI_girl.png', '/home/user1/Pictures/AI_girl.png')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/BTC_icon_orange.jpg', '/home/user1/venvpython/images/BTC_icon_orange.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/BTC_icon_black.jpg', '/home/user1/venvpython/images/BTC_icon_black.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/BTC_icon_green.jpg', '/home/user1/venvpython/images/BTC_icon_green.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/BTC_icon_grey.jpg', '/home/user1/venvpython/images/BTC_icon_grey.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/BTC_icon_blue.jpg', '/home/user1/venvpython/images/BTC_icon_blue.jpg')
else:
	messagebox.showinfo("Information", "OK. Cancelling software update process.")

