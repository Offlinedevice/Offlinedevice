#!/usr/bin/env python3
#
#  Update script for GUIApp.py v0.3.2
#  
#  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, 
#  version 2 of the License.

#  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
#  See the GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

#  SPDX-License-Identifier: GPL-2.0-only
#  GUIApp.py - Offline device.
#  Copyright (c) 2024 

import tkinter
import shutil
from tkinter import messagebox

answer = messagebox.askquestion('Important!', 'Before update to program version 0.3.2 you have to install version 0.3.1 first.\n Have you done that?')

if answer == 'yes':
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/GUIApp.py', '/home/user1/venvpython/GUIApp.py')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/yubikeyHelp.txt', '/home/user1/venvpython/help/yubikeyHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/boltcardHelp.txt', '/home/user1/venvpython/help/boltcardHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/digitalIDHelp.txt', '/home/user1/venvpython/help/digitalIDHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/securearchiveHelp.txt', '/home/user1/venvpython/help/securearchiveHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/gpgHelp.txt', '/home/user1/venvpython/help/gpgHelp.txt')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/getstartedHelp.txt', '/home/user1/venvpython/help/getstartedHelp.txt')

	shutil.copyfile('/home/user1/tempsystem/Updatefiles/blackbackground.jpg', '/home/user1/venvpython/images/blackbackground.jpg')
	shutil.copyfile('/home/user1/tempsystem/Updatefiles/black.jpg', '/home/user1/venvpython/images/black.jpg')
else:
	messagebox.showinfo("Information", "OK. Cancelling software update process.")

